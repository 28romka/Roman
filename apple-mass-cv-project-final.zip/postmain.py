from ultralytics import YOLO
import os

# Загружаем нашу обученную модель на яблоках (лежит в корне проекта)
model = YOLO('best.pt')
model.fuse()  # Оптимизация для ускорения инференса

# Запрашиваем путь к фото
path = input('Укажите путь к фото яблока (или нажмите Enter для тестового фото): ').strip()

# Если ничего не ввели — используем тестовое фото (замените на своё, если нужно)
if not path:
    path = 'istockphoto-184276818-612x612.jpg'  # Имя вашего тестового файла

# Убираем кавычки, если пользователь ввёл путь в кавычках
if path.startswith('"') and path.endswith('"'):
    path = path[1:-1]

# Проверяем существование файла
if not os.path.exists(path):
    print(f"Ошибка: файл '{path}' не найден в папке проекта!")
    print("Доступные файлы:")
    !ls *.jpg *.jpeg *.png  # Покажет изображения в корне
    exit()

print(f"\nОбрабатываем фото: {path}")

# Инференс модели
results = model(path, save=True, show=False)[0]  # save=True сохранит аннотированное фото в runs/detect

# Анализ результатов
boxes = results.boxes
if len(boxes) == 0:
    print("На фото яблоко не обнаружено!")
    exit()

# Берём первое найденное яблоко (предполагаем, что на фото одно)
box = boxes[0]
cls_id = int(box.cls[0].item())          # 0 = apple, 1 = damaged_apple
conf = float(box.conf[0].item())         # Уверенность
class_name = 'здоровое яблоко' if cls_id == 0 else 'повреждённое яблоко'

# Координаты bounding box
x1, y1, x2, y2 = box.xyxy[0].tolist()
width_px = x2 - x1
height_px = y2 - y1
area_px = width_px * height_px

# Примерный расчёт массы
# Упрощённая калибровка: подберите коэффициенты под свои фото
# Пример: при ширине ~350–450 px яблоко весит ~130–180 г
estimated_mass = round(0.4 * width_px + 0.2 * height_px)  # Можно менять для точности

# Красивый вывод результата
print("\n" + "="*60)
print("               АНАЛИЗ ФОТОГРАФИИ ЯБЛОКА")
print("="*60)
print(f"Класс яблока          : {class_name}")
print(f"Уверенность модели    : {conf:.1%}")
print(f"Размеры (ширина × высота): {width_px:.0f} × {height_px:.0f} пикселей")
print(f"Площадь объекта       : {area_px:.0f} пикселей²")
print(f"Приблизительная масса : {estimated_mass} грамм")
print("="*60)

# Информация о сохранённом изображении
save_dir = results.save_dir
print(f"\nАннотированное фото (с боксом и классом) сохранено в:")
print(f"   {save_dir}")

print("\nГотово! Проект успешно определил массу яблока по фото.")