from ultralytics import YOLO
import os

# Загружаем нашу модель на яблоках
model = YOLO('best.pt')
model.fuse()

# Путь к фото
path = input('Укажите путь к фото яблока (или Enter для теста): ').strip()
if not path:
    path = 'istockphoto-184276818-612x612.jpg'  # Твоё тестовое фото

print(f"Обрабатываем: {path}")

# Инференс
results = model(path, save=True, show=True)[0]

boxes = results.boxes
if len(boxes) == 0:
    print("Яблоко не найдено!")
else:
    box = boxes[0]
    cls = int(box.cls[0])
    conf = float(box.conf[0])
    class_name = 'здоровое яблоко' if cls == 0 else 'повреждённое яблоко'

    x1, y1, x2, y2 = box.xyxy[0].tolist()
    width_px = x2 - x1
    height_px = y2 - y1

    # Примерная калибровка массы (подбери под свои фото)
    estimated_mass = round((width_px + height_px) / 4)  # Пример: среднее ~140–160г

    print("\n=== РЕЗУЛЬТАТ ===")
    print(f"Класс: {class_name}")
    print(f"Уверенность: {conf:.2%}")
    print(f"Размеры: {width_px:.0f} × {height_px:.0f} пикселей")
    print(f"Приблизительная масса: {estimated_mass} г")